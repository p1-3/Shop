const products=[
 {name:"ไอดี Free Fire #001",game:"FREE FIRE",icon:"🔥",desc:"ตัวอย่างสินค้า • แก้ไขข้อมูลได้",price:299},
 {name:"ไอดี Roblox #002",game:"ROBLOX",icon:"🧱",desc:"ตัวอย่างสินค้า • แก้ไขข้อมูลได้",price:199},
 {name:"ไอดี Blox Fruits #003",game:"BLOX FRUITS",icon:"🍎",desc:"ตัวอย่างสินค้า • แก้ไขข้อมูลได้",price:349},
 {name:"ไอดี FIFA #004",game:"FC / FIFA",icon:"⚽",desc:"ตัวอย่างสินค้า • แก้ไขข้อมูลได้",price:499}
];

const grid=document.querySelector("#grid"), search=document.querySelector("#search");
function render(list){
 grid.innerHTML=list.map((p,i)=>`<article class="card"><div class="thumb">${p.icon}</div><div class="card-body"><div class="game">${p.game}</div><h3>${p.name}</h3><p class="desc">${p.desc}</p><div class="price">฿${p.price.toLocaleString()}</div><a class="buy" href="#contact">สนใจสินค้านี้</a></div></article>`).join("");
}
render(products);
search.addEventListener("input",e=>{
 const q=e.target.value.toLowerCase();
 render(products.filter(p=>(p.name+" "+p.game+" "+p.desc).toLowerCase().includes(q)));
});